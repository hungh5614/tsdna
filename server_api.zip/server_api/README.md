## REQUIRED
#node: v18.18.0
#mysql: latest

## Installation

```bash
$ npm install
```

## Running the app

```bash
$ npm run start:prod

#SERVER_PORT=8080 => API: localhost:8080